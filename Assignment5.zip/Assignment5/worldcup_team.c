#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "readline.h"
#define NAME_LEN 25
#define SEED 2
struct team{

    int code; // team code variable
    char name[NAME_LEN+1]; //creating a string in c is an array of characters
    char seeds[SEED+1]; // group seeding
    char colour[7]; // coulour
    struct team *next;
};
struct team *tHead = NULL; /* points to first team */
struct team *find_team(int code);


void insert(void);
void search(void);
void update(void);
void print(void);
int tcheck(int code) {
    struct team *node = tHead;
    for (; node != NULL; node = node->next) {
        if (node->code == code) {
            return 1;
        }
    }
    return 0;
}
void teams(void){
    char code;
    printf("Enter operation code: ");
    scanf(" %c", &code);
    switch (code) { // takse input: i,s,u,p,q

        case 'i':
            insert(); // goes to insert function
            break;
        case 's':
            search(); // goes to search function
            break;
        case 'u':
            update(); // goes to update function
            break;
        case 'p':
            print(); // goes to print functionn
            break;
        case 'q':
             printf("Goodbye."); // if quit is entered then goodbye is output
                // ends the loop
               break;
        default:
            printf("Invalid input, try again.\n"); // if a letter which is not permissable is entered
            break;
    }


}
/*struct team *find_team(int code1)
{
    struct team *p;
    for (p = fullTeam; p != NULL && code1 > p->code; p = p->next)
    if (p != NULL && code1 == p->code) {
        printf("This exists");
        return p;
    }
    return NULL;
}
*/
/*int checkCode(int codenum){
    struct team *temp;
    int count = 1;
    int check = 0;
    for (temp = tHead; temp !=NULL; temp = temp->next)
    {
        if(temp->code == codenum) {
            check = 1;
            printf("trash");
            return check;

        }
    }
    return check;
} */
void insert(void) {
    struct team *cur, *prev, *newNode;
    struct team *temp;
    char name1[NAME_LEN];
    int count = 0;
    int check = 0;
    newNode = (struct team*)malloc(sizeof(struct team));
    int code1;
    char colour1[7];
    char seed[NAME_LEN];


    do{
        printf("Please enter a team code:");
        scanf("%d", &code1);
        newNode->code = code1;
        count = 1;
        for (temp = tHead; temp !=NULL; temp = temp->next){
            if(temp->code == code1){
                count = 0;
                printf("This team already exists.");
                return;
                // Call funtion again to check if the inputed code is outside the acceptable range
            }

        }




    }while(count == 0);


    for (cur = tHead, prev = NULL; cur != NULL; prev = cur, cur = cur->next);

    do{
        printf("\nPlease enter a Team name:");
        read_line(name1,NAME_LEN);
        count =1;
        for (temp = tHead; temp !=NULL; temp = temp->next){
            if(strcmp(name1,temp->name)== 0 ){
                printf("\nThis team already exists.");
                count = 0;

                // Call funtion again to check if the inputed code is outside the acceptable range
            }
        }
        strcpy(newNode->name,name1);

    }while(count == 0);

    do{
        printf("\nPlease enter group seeding:");
        read_line(seed,SEED);
        count =1;
        if (seed[0]<65 || seed[0]>75){
            printf("\nPlease try again. Letter has to be between A and H)");
            count =0;
        }
        if (seed[1] <49 || seed[1]>52){
            printf("Please Try again. Number has to be between 1 and 4");
            count =0;
        }
        for (temp = tHead; temp !=NULL; temp = temp->next){
            if(strcmp(temp->seeds,seed)==0 ){
                printf("\nno this is bad");
                count = 0;
                return;

                // Call funtion again to check if the inputed code is outside the acceptable range
            }
        }
        strcpy(newNode->seeds,seed);

    }while(count == 0);


    printf("\nPlease enter Primary kit colour:");
    read_line(colour1, 7);
    count = 0;
    char colours[7] = {'R', 'O', 'Y', 'G', 'B', 'I', 'V'};
    char arcfull[][10] = {"Red", "Orange", "Yellow", "Green", "Blue", "Indigo",
                          "Violet"};// this converts the letter input to full name input


    for (int counter = 0; counter < 7; counter++) {
        if (colour1[0] == colours[counter]) {
            for (int count2 = 0; count2 < 7; count2++) {
                if (colour1[0] == colours[count2]) {
                    strcpy(newNode->colour, arcfull[count2]);
                    count = 1;
                }
            }
        }
    }
    if (count == 0) {
        printf("This is an invalid colour. Try again ROYGBIV.");
        return;
    }
    newNode->next = cur;
    if(prev ==NULL)
        tHead = newNode;
    else
        prev->next = newNode;

}
void search(void){
    {
        int code;
        int check =0;
        struct team *temp;
        printf("Enter team code: ");
        scanf("%d", &code);
        for (temp = tHead; temp !=NULL; temp = temp->next)
        {
            if(code == temp->code)
            {
                check = 1;
                printf("\nTeam Code\tTeam Name\tGroup Seeding\t  Colour\n");
                printf("%d\t%14s\t%18s\t%3s\n", temp->code, temp->name, temp->seeds, temp->colour);
            }
        }
        if (check ==0){
            printf("This team does not exist.Please Try again.");
            return;

        }

    }
}
void update(void){
    int code;
    struct team *temp;
    struct team *cur, *prev, *newNode;
    char name1[NAME_LEN];
    int count = 0;
    int check = 0;
    int code1;
    char colour1[7];
    char seed[NAME_LEN];
    printf("Enter team code: ");
    scanf("%d", &code);

    for (;temp !=NULL; temp = temp->next){
        if(code == temp->code){
            newNode = malloc(sizeof(struct team));
            if (newNode == NULL) {
                printf("\tThere is not enough space in memory to make an update.\n");
                return;
            }
            for (temp=tHead;temp !=NULL; temp = temp->next);
            printf("\nPlease enter a Team name:");
            scanf(" %[^\n]", &temp->name);
            printf("\tEnter group seeding: ");
            scanf("%s", &temp->seeds);
            do
            {
                //printf("\nfirst digit of seeds: %c", teamNewNode->seeds[0]);
                if (temp->seeds[0] < 65 || temp->seeds[0] > 72)
                {
                    // Tell the user the error and ask for a new input
                    printf("\nThe letter is outside of the accepted range (A-H)");
                    printf("\nPlease input another group seeding: ");
                    scanf("%s", &temp->seeds);
                    check = 1;
                }
                    // Check if ACSII value for second digit of the team code is within the acceptable range
                else if (temp->seeds[1] < 49 || temp->seeds[1] > 52)
                {
                    // Tell the user the error and ask for a new input
                    printf("\nThe number is outside of the accepted range (1-4)");
                    printf("\nPlease input another group seeding: ");
                    scanf("%s", &temp->seeds);
                    check = 1;
                }
                for (temp = tHead; temp !=NULL; temp = temp->next)
                {
                    if(strcmp(temp->seeds, temp->seeds) == 0)
                    {
                        check = 1;
                        // ask for another input
                        printf("\nThe group seeding entered is already being used");
                        printf("\nPlease enter a unique group seeding: ");
                        scanf("%s", &temp->seeds);
                    }
                    else
                    {
                        temp->code = code;
                        check = 0;
                    }
                }

            }while (check == 1);

            printf("\nPlease enter Primary kit colour:");
            read_line(colour1, 7);
            count = 0;
            char colours[7] = {'R', 'O', 'Y', 'G', 'B', 'I', 'V'};
            char arcfull[][10] = {"Red", "Orange", "Yellow", "Green", "Blue", "Indigo",
                                  "Violet"};// this converts the letter input to full name input


            for (int counter = 0; counter < 7; counter++) {
                if (colour1[0] == colours[counter]) {
                    for (int count2 = 0; count2 < 7; count2++) {
                        if (colour1[0] == colours[count2]) {
                            strcpy(newNode->colour, arcfull[count2]);
                            count = 1;
                        }
                    }
                }
            }
            if (count == 0) {
                printf("This is an invalid colour. Try again ROYGBIV.");
                return;
            }



            /*printf("\nPlease enter a Team name:");

            read_line(tTemp->name,NAME_LEN);
            do{
                count = 0;
                for (tTemp = tHead; tTemp !=NULL; tTemp = tTemp->next) {
                    if (strcmp(name1, tTemp->name) == 0) {
                        printf("\nno this is bad");
                        count = 1;
                        // Call function again to check if the inputed code is outside the acceptable range
                    }

                }
                strcpy(tTemp->name, name1);
            }while(count == 0); */
              /*  printf("\nPlease enter a Team name:");
                read_line(name1,NAME_LEN);
                count =1;
                for (temp = tHead; temp !=NULL; temp = temp->next){
                    printf("tHIS IS stupid");
                    printf("%s",temp->name);
                    if(strcmp(temp->name,name1) == 0 ){
                        printf("\nno this is bad");
                        temp = tHead;
                       count = 0;
                       break;
                        // Call function again to check if the inputed code is outside the acceptable range
                    }
                }
                if(count == 1) {
                    strcpy(temp->name, name1);
                } */
//
        }
    }
}
void print(void)
{
    struct team *p;
    printf("Team Code\tTeam Name\tGroup Seeding\t  Colour\n");
    for (p = tHead; p != NULL; p = p->next)
        printf("%d\t%14s\t%18s\t%3s\n", p->code, p->name, p->seeds, p->colour);
}

