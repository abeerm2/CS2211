
#ifndef ASSIGNMENT5_READLINE_H
#define ASSIGNMENT5_READLINE_H
int read_line(char str[], int n);
#endif //ASSIGNMENT5_READLINE_H
