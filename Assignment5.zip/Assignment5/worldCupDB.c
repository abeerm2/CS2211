#include <stdbool.h>
#include "headers.h"
int main() {
    char ans;
    bool func = true;

    // this section runs an infintie loop until the user asks to quit the program
    while (func == true) {
        printf("\nWhich operation would you like to complete:");
        scanf(" %c", &ans);
        switch (ans) { // takse input: i,s,u,p,q

            case 'h':
                printf("\nCommands:\nh for help.\nq to quit.\n\n"
                       "t to control teams.\n\ti to insert.\n\ts to insert.\n\tu to update.\n\tp to print.\n\td to delete.\n\tr to print registered players.\n\n"
                       "p to control players.\n\ti to insert.\n\ts to search.\n\tu to update.\n\tp to print.\n\td to delete.\n\n"
                );
                break;
            case 'q':
                printf("\nGoodbye. Thank you for using this program.");//search(); // goes to search function
                break;
            case 't':
                teams(); // goes to update function
                break;
            case 'p':
               player();// print(); // goes to print functionn
                break;
            default:
                printf("Invalid input, try again.\n"); // if a letter which is not permissable is entered
                break;
        }
    }
    return 0;
}