#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "readline.h"

#define NAME_LEN 49


struct player
{
    // Define variables that are part of the Team structre
    int code;
    char name[50];
    int age;
    char club[50];
    struct player *next;
};
struct player *pHead = NULL;
void insert(void);
void search(void);
void update(void);
void print(void);
void delete(void);

void player() {
    printf("Please select an operation: ");
    char code;
    scanf(" %c", &code);
    switch(code) {
        case 'i':
            insert();
            break;
        case 's':
            search();
            break;
        case 'u':
            update();
            break;
        case 'p':  //traverse entire player linked list print out player attributes
            print();
            break;
        case 'd':   //pass the list's head as an argument and get back the new list without the node to be deleted
            delete();
            break;
        default:
            printf("\t\t\tCould not recognize code. Try again.\n\n");
    }
}


void print(void)
{
    struct player *temp;

    //iterate the entire linked list and print the data
    printf("\nplayer Code  player Name               player age               Club\n");

    for (temp = pHead; temp !=NULL; temp = temp->next)
        printf("%-10d   %-25.25s %-24d %s\n", temp->code, temp->name, temp->age, temp->club);
}

void insert(void)
{
    struct player *temp;
    char tmpColour;
    int check = 0;
 
        struct player *cur, *prev, *newNode;
        newNode = malloc(sizeof(struct player));

        // Ask for user to input team code
        printf("\tEnter player code: ");
        scanf("%d", &newNode->code);
        do
        {
            // Check if the inputed team code is already being used
            for (temp = pHead; temp !=NULL; temp = temp->next)
            {
                if(temp->code == newNode->code)
                {
                    check = 1;
                    // Tell user the error ans ask for another input
                    printf("\nThe player code entered is already being used");
                    printf("\nPlease enter another player code: ");
                    scanf("%d", &newNode->code);
                }
                else if(newNode->code < 0)
                {
                    check = 1;
                    // Tell user the error ans ask for another input
                    printf("\nThe player code entered is outsie of accepted range (code must be greater then 0)");
                    printf("\nPlease enter another player code: ");
                    scanf("%d", &newNode->code);
                }
                else
                {
                    check = 0;
                }
            }
        }while (check == 1);
        for (cur = pHead, prev = NULL; cur != NULL; prev = cur, cur = cur->next);

        printf("\tEnter player Name: ");
        scanf(" %[^\n]", &newNode->name);
        do
        {
            if(strlen(newNode->name)>49)
            {
                check = 1;
                printf("\nThe player name entered is too long (greater than 50 characters)");
                printf("\nEnter player Name: ");
                scanf(" %[^\n]", &newNode->name);
            }
            else
            {
                check = 0;
            }
        } while (check == 1);


        printf("\tEnter player age: ");
        scanf("%d", &newNode->age);
        do
        {
            if (newNode->age < 17 || newNode->age > 99){
                printf("\nThe player age entered is outside of accepted range (17-99)");
                printf("\nPlease enter another player age: ");
                scanf("%d", &newNode->age);
                check = 1;
            }
            else{
                check = 0;
            }
        }while (check == 1);

        printf("\tEnter club affiliation ");
        scanf(" %[^\n]", &newNode->club);
        do
        {
            if(strlen(newNode->club)>49){
                check = 1;
                printf("\nThe club affiliation entered is too long (greater than 50 characters)");
                printf("\nEnter player Name: ");
                scanf(" %[^\n]", &newNode->club);
            }
            else{
                check = 0;
            }
        } while (check == 1);

        newNode->next = cur;
        if(prev ==NULL)
            pHead = newNode;
        else
            prev->next = newNode;


    }
void search(void)
    {
        int code;
        printf("Enter player code: ");
        scanf("%d", &code);
        struct player *temp;
        for (temp = pHead; temp !=NULL; temp = temp->next){
            if(code == temp->code)
            {
                printf("\nplayer Code  player Name               player Name               Club\n");
                printf("%-10d  %-24.24s   %-27d %s\n", temp->code, temp->name, temp->age, temp->club);
            }
        }
    }
    void update (void)
    {
        int code;
        int check = 0;
        printf("Enter player code: ");
        scanf("%d", &code);
        struct player *temp;
        for (temp = pHead; temp !=NULL; temp = temp->next)
        {
            if(code == temp->code)
            {
                printf("\tEnter player Name: ");
                scanf(" %[^\n]", &temp->name);
                do
                {
                    if(strlen(temp->name)>49)
                    {
                        check = 1;
                        printf("\nThe player name entered is too long (greater than 50 characters)");
                        printf("\nEnter player Name: ");
                        scanf(" %[^\n]", &temp->name);
                    }
                    else
                    {
                        check = 0;
                    }
                } while (check == 1);

                printf("\tEnter player age: ");
                scanf("%d", &temp->age);
                do
                {
                    if (temp->age < 17 || temp->age > 99)
                    {
                        printf("\nThe player age entered is outside of accepted range (17-99)");
                        printf("\nPlease enter another player age: ");
                        scanf("%d", &temp->age);
                        check = 1;
                    }
                    else
                    {
                        check = 0;
                    }
                }while (check == 1);

                printf("\tEnter club affiliation: ");
                scanf(" %[^\n]", &temp->club);
                do
                {
                    if(strlen(temp->club)>49)
                    {
                        check = 1;
                        printf("\nThe club affiliation entered is too long (greater than 50 characters)");
                        printf("\nEnter player Name: ");
                        scanf(" %[^\n]", &temp->club);
                    }
                    else
                    {
                        check = 0;
                    }
                } while (check == 1);
            }
        }
    }

void delete(void){
        int count = 1;
        int code;
        printf("Enter player code: ");
        scanf("%d", &code);
        struct player *temp;
        for (temp = pHead; temp !=NULL; temp = temp->next)
        {
            if(code == temp->code && count == 1)
            {
                temp = pHead;
                pHead = pHead->next;
                free(temp);
            }
            else if (code == temp->code && temp->next == NULL)
            {
                struct player *end = pHead;
                struct player *prev = NULL;
                while(end->next)
                {
                    prev = end;
                    end = end->next;
                }
                prev->next = NULL;
                free(end);
            }
            else if (code == temp->code && temp->next != NULL)
            {
                struct player *prev;
                temp = pHead;
                prev = pHead;
                for(int i = 0; i < count; i++)
                {
                    if(i == 0 && count == 1)
                    {
                        pHead = pHead->next;
                        free(temp);
                    }
                    else
                    {
                        if (i == count - 1 && temp)
                        {
                            prev->next = temp->next;
                            free(temp);
                        }
                        else
                        {
                            prev = temp;
                            if(prev == NULL)
                                break;
                            temp = temp->next;
                        }
                    }
                }
            }
            count++;
        }
    }

