#ifndef DEFINITIONS_H_INCLUDED
#define DEFINITIONS_H_INCLUDED
void printArrays (int ***tab2, int arrs2, int row2, int column2);
void initArrays (int ***tab, int arrs, int row, int column);
void combineArrays (int ***tab, int arrs, int row, int column);
void player(void);
void teams(void);
#endif // DEFINITIONS_H_INCLUDED
