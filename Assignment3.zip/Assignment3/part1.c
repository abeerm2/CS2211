#include <stdio.h>

int main() {

    int size; //size of array
    int i;

    printf("Please enter the size of array you would like (5 to 12):"); //asks for array size
    scanf("%d",&size);
    int arr[size];
    printf("size of array is %d and bytes is %d", (sizeof(arr)/sizeof(int)),sizeof(arr)); // outputs the size of the array and number of bytes
    printf("\nPlease enter the integer values separated by spaces:"); //asks for input

    for (i=0;i<(sizeof(arr)/sizeof(int));i++) {

        scanf("%d", &arr[i]);

    } // runs through loop to add input into array


    //calling all functions

    printElement(arr, sizeof(arr)/sizeof(int));
    printLargest(arr, sizeof(arr)/sizeof(int));
    printReverse(arr, sizeof(arr)/sizeof(int));
    printSum(arr, sizeof(arr)/sizeof(int));
    printOrder(arr, sizeof(arr)/sizeof(int));
    elementSwap(arr, sizeof(arr)/sizeof(int));

    return 0;




}
int printElement (int array[],int size){ // this function prints out just the array with its point in the array

    printf("\nYour array is: ");
    for (int i =0;i<size;i++){
        printf("[%d] = %d ", i, array[i]);

    }

    return 0;
}
int printLargest(int array[], int size){ //prints the largest value in the array by parsing through the array and comparing the next and current value in the array
    int current = array[0];
    int next;
    for (int i =1;i<size;i++){
        next = array[i];
        if (current<next){ // if ur current number is less than the next number in the array, then it can be replaced as the largest
            current = next;
        }
    }
    printf("\nThe Largest value in your array is %d",current);
    return 0;
}
int printReverse(int array[], int size){ // prints the array in reverse by running through the loop backwards
    printf("\nYour array in reverse is: ");
    for (int i = size-1;i>=0;i--){
        printf("[%d] = %d ", i, array[i]);

    }
    return 0;
}
int printSum(int array[], int size){//parses through the array and adds up each value in the array
    int sum=0;
    for (int i=0 ;i<size;i++){
        sum = sum + array[i]; //continuously sums until the array size has been reached
    }
   printf("\nThe sum of this array is %d",sum);
    return 0;
}
int printOrder(int array[],int size){ //prints the array in descending order
    int newArr[size];
    for (int k=0;k<size;k++){ //puts the array into another array to avoid messing with inputted array
        newArr[k]=array[k];
    }
    int temp;
    for (int j = 0; j<size;j++) { //this loops parses through the array and compares the next and current array value and orders them
        for (int i = j+1; i < size; i++) {
            if (newArr[j] < newArr[i]) {
                temp = newArr[j];
                newArr[j]=newArr[i];
                newArr[i] = temp;
            }

        }

    }
    printf("\nIn Descending Order,");
    printElement(newArr,size); //sends the array to printelement to print out the array
    return newArr;

}
int elementSwap(int array[], int size){ //swaps the last member of the array with the first member
    printf("\n\nArray before :");
    printElement(array,size);
    int first = array[0]; //finds first value
    array[0]=array[size-1]; //finds last using total size minus 1 because arrays start at zero
    array[size-1]=first; //assigns last variable to the first
    printf("\nArray after:");
    printElement(array,size);

}