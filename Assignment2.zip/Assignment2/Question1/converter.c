#include <stdio.h>
#include <stdbool.h>
#include <string.h>
/*Abeer Muhammad
 * Student Number: 251143649
 * Date : October 9, 2022
 * Function: This code takes the input of the user, and convert the users number with a range
 * of units, they will also select the conversion they wish to make
 */
int main() {
    //assign variables
    int selection; //user input
    char answer [1];
    float value; //value converted
    float final;
    bool func = true;
    while (func == true)
    {
        //conversion for kg to lbs
        //gets user input
    printf("Welcome to the Converter.\n1. Kilograms and Pounds\n2. Hectares and Acres\n3. Litres and Gallons\n4. Kilometre and Mile\n5. Quit\nPlease select which task you'd like to complete:");
    scanf ("%d",&selection);

    printf("Your Selection is: %d\n", selection);
    //runs through each case based on the selection (1-5)
        switch (selection) {
            case 1:
                //asks user which direction for the conversion they want to make
                printf("\nWould you like to convert Kilo to Pound (Enter \" K \") or Pound to Kilo (Enter \" P \"): ");
                scanf("%s", &answer);
                //this takes the answer given as a string and allows you to check if true
                if (strcmp(answer, "K") == 0 || strcmp(answer, "P") == 0){
                    //asks user for numerical value
                    printf("\nPlease enter the value you'd like to convert: ");
                    scanf ("%f",&value);
                    //if its kg to lb then preforms conversion below
                    if (strcmp(answer,"K") ==0){
                        final = value*2.20462;
                        printf("\n%.3f is %.3f lbs\n", value, final);
                    }
                    //else if lb to ckg, converts below
                    else {
                        final = value/2.20462;
                        printf("\n%.3f is %.3f kg\n", value, final);
                    }
                }
                //if user inputs incorrect value, tells them to start from beginning
                else{
                    printf("Invalid Input. Try again.\n");
                }
                break;
                //if they select the second option h to a, takes them here
            case 2:
                //asks which direction theyd like to take for the conversion
                printf("Would you like to convert Hectares to Acres (Enter \" H \") or Acres to Hectares (Enter \" A \"): ");
                scanf("%s", &answer);
                //if one of them equals true then they ask for the value needed to convert
                if (strcmp(answer, "H") == 0|| strcmp(answer, "A") ==0){
                    printf("\nPlease enter the value you'd like to convert: ");
                    scanf ("%f",&value);
                    if (strcmp(answer,"H") == 0){//if it was from h to a then preforms following conversion
                        final = value*2.47105;
                        printf("\n%.3f Hectares is %.3f Acres\n", value, final);
                    }
                    else{ //otherwise a to h and preforms conversion
                        final = value/2.47105;
                        printf("\n%.2f is %.3f Hectares\n", value, final);
                    }
                }
                else{ //invalid if they entre the incorrect letter and takes them back to beginning
                    printf("Invalid Input. Try again.");
                }
                break;
                //if they want to convert litres to gallons, then preforms below function
            case 3:
                //asks user what direction they'd like to take for conversion
                printf("Would you like to convert Litres to Gallons (Enter \" L \") or Gallons to Litres (Enter \" G \"): ");
                scanf("%s", &answer);
                //if one of them is true, then they will ask for the value required
                if (strcmp(answer, "G") ==0 || strcmp(answer, "L") ==0){
                    printf("\nPlease enter the value you'd like to convert: ");
                    scanf ("%f",&value);
                    if (strcmp(answer,"L") == 0){ //if l to g is wanted then preforms below conversion
                        final = value*0.264172;
                        printf("\n%.3f Litres is %.3f Gallons\n", value, final);
                    }
                    else{ //otherwise goes g to l and preforms below
                        final = value/0.264172;
                        printf("\n%.2f Gallons is %.3f Litres\n", value, final);
                    }
                }
                else{ //user entered wrong letter
                    printf("Invalid Input. Try again.");

                }
                break;
                //final option is to convert km to miles
            case 4:
                //asks user for direction they want
                printf("Would you like to convert Kilometre to Miles (Enter \" K \") or Miles to Kilometres (Enter \" M \"):");
                scanf("%s", &answer);
                if (strcmp(answer, "K") ==0 || strcmp(answer, "M") ==0){ //if one is true then does below
                    printf("\nPlease enter the value you'd like to convert: ");
                    scanf ("%f",&value);
                    if (strcmp(answer,"K") == 0){ //if k to m is wanted then does this conversion
                        final = value*0.621371;
                        printf("\n%.3f Kilometres is %.3f Miles\n", value, final);
                    }
                    else{ //if not true then its m to km and does below
                        final = value/0.621371;
                        printf("\n%.2f Miles is %.3f Kilometres\n", value, final);
                    }

                }
                else{ //user entered wrong letter
                    printf("\nInvalid Input. Try again.");
                }
                break;
            case 5: //if they enter 5 then program is done running and says goodbye
                printf("Thank you for using this converter. Goodbye.");
                func = false;
                break;
            default: //if a wrong number is selected at home page.
                printf("Invalid Input. Try again.\n");
        }
    }
    return 0;
}
