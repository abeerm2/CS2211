/*Abeer Muhammad
 * Student Number: 251143649
 * Date : October 9, 2022
 * Function: This code takes the input of the user, and with the use of arrays it will
 * convert the numerical number into its written format
 */
#include <stdio.h>
#include <stdbool.h>

int main() {
    //initializes all variables
    char ones [10][10] = {"one","two","three","four","five","six","seven","eight","nine","ten"}; //for ones column and hundreds
    char tens [17][10] = {"eleven","twelve", "thirteen","fourteen","fifteen","sixteen","seventeen","eighteen","nineteen","twenty","thirty","fourty","fifty","sixty","seventy","eighty","ninety"}; //tens column
    int input; //for input from user
    int num1; //ones column
    int num2; //tens
    int num3; //hundreds
    int numcur; //current number
    int workarr [4]; //array with digits separated
    int i;
    int count;


while (true) { //this is to keep the code running continuously until it is broken
    //resets variables
    count =0;
    i=0;
    //asks and gets user input to assign to input
    printf("\nPlease enter a number to convert to words:");
    scanf("%d", &input);

    //checks if user input is zero because then it will break the code
    if (input ==0){
        printf("\nThank you for using my converter. GOODBYE.");
        break;
    }
    //otherwise it will run the below code
    else {
        //if input is not equal to zero then will run the below code which will separate the digits of the number
        while (input != 0) {
            numcur = input % 10; //mod 10 to get remainder
            workarr[i] = numcur;
            i++;
            input = input / 10;
            count++; //this is counting how long the inputted number is
        }
        num1 = workarr[0]; //assigns all three digs separately
        num2 = workarr[1];
        num3 = workarr[2];
        printf("Your Number is: ");

        //this will now print out the written number

        if (count == 1) { //if one digit
            printf("%s ", ones + (num1 - 1));
        }
        else if (count == 2) { //if two digit
            if (num1 > 0 && num2 > 0 && num2 < 2) { //if it falls between (and including) 11 and 19
                printf("%s ", tens + (num1 - 1));

            }

            if (num2 >= 2) { //if its greater than or equal to 20
                printf("%s ", tens + (num2 + 7));
                if (num1 != 0) {
                    printf("%s ", ones + (num1 - 1));
                }
            } else if (num2 == 1 && num1 == 0) { //adds the second digit in a two digit number greater than 20 like 22
                printf("%s ", ones + (num1 + 9));
            }

        }
        //if 3 digit number
        else if (count == 3) {
            printf("%s hundred ", ones + (num3 - 1)); //starts with hundreds
            if (num1 >= 1 && num2 == 0) {
                printf("and %s ", ones + (num1 - 1)); //prints ten if required
            }
            if (num1 > 0 && num2 > 0 && num2 < 2) { //if within 10 and 20
                printf("%s ", tens + (num1 - 1));

            }
            if (num2 >= 2) { // 20 and above
                printf("%s ", tens + (num2 + 7));
                if (num1 != 0) {
                    printf("%s ", ones + (num1 - 1));
                }
            }
            else if (num2 == 1 && num1 == 0) { //if only 10 is inputted by user
                printf("%s ", ones + (num1 + 9));
            }
        }

    }
}
    return 0;
}
