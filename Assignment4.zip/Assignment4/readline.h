//
// Created by Abeer on 11/2/2022.
//

#ifndef ASSIGNMENT4_READLINE_H
#define ASSIGNMENT4_READLINE_H
int read_line(char str[], int n);
#endif //ASSIGNMENT4_READLINE_H
